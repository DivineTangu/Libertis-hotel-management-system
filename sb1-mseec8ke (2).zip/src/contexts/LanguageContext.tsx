import React, { createContext, useContext, useState } from 'react';

type Language = 'en' | 'fr';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // Header
    dashboard: 'Dashboard',
    booking: 'Booking',
    admin: 'Admin Panel',
    
    // Dashboard
    liveOccupancy: 'Live Occupancy',
    revenueBreakdown: 'Revenue Breakdown',
    todayAlerts: "Today's Alerts",
    rooms: 'Rooms',
    eventHall: 'Event Hall',
    restaurant: 'Restaurant',
    pool: 'Pool',
    checkins: 'Check-ins',
    checkouts: 'Check-outs',
    eventBookings: 'Event Bookings',
    totalRevenue: 'Total Revenue',
    
    // Booking
    roomBooking: 'Room Booking',
    eventBooking: 'Event Booking',
    restaurantBooking: 'Restaurant Booking',
    amenitiesBooking: 'Amenities Booking',
    guestDetails: 'Guest Details',
    name: 'Name',
    phone: 'Phone',
    email: 'Email',
    passport: 'Passport',
    checkinDate: 'Check-in Date',
    checkoutDate: 'Check-out Date',
    roomType: 'Room Type',
    standard: 'Standard',
    deluxe: 'Deluxe',
    suite: 'Suite',
    paymentMethod: 'Payment Method',
    mobileMoneyMTN: 'Mobile Money (MTN)',
    mobileMoneyOrange: 'Mobile Money (Orange)',
    creditCard: 'Credit Card',
    cash: 'Cash',
    
    // Admin
    resourceAllocation: 'Resource Allocation',
    roomInventory: 'Room Inventory',
    eventCalendar: 'Event Calendar',
    staffRoles: 'Staff Roles',
    
    // Status
    occupied: 'Occupied',
    available: 'Available',
    maintenance: 'Maintenance',
    clean: 'Clean',
    
    // Currency
    fcfa: 'FCFA',
    
    // Special
    visaAssistance: 'Visa Assistance',
    airportPickup: 'Airport Pickup',
    tourismTax: 'Tourism Tax',
  },
  fr: {
    // Header
    dashboard: 'Tableau de Bord',
    booking: 'Réservation',
    admin: 'Panneau Admin',
    
    // Dashboard
    liveOccupancy: 'Occupation en Temps Réel',
    revenueBreakdown: 'Répartition des Revenus',
    todayAlerts: "Alertes d'Aujourd'hui",
    rooms: 'Chambres',
    eventHall: 'Salle d\'Événements',
    restaurant: 'Restaurant',
    pool: 'Piscine',
    checkins: 'Arrivées',
    checkouts: 'Départs',
    eventBookings: 'Réservations d\'Événements',
    totalRevenue: 'Revenu Total',
    
    // Booking
    roomBooking: 'Réservation de Chambre',
    eventBooking: 'Réservation d\'Événement',
    restaurantBooking: 'Réservation Restaurant',
    amenitiesBooking: 'Réservation Équipements',
    guestDetails: 'Détails du Client',
    name: 'Nom',
    phone: 'Téléphone',
    email: 'Email',
    passport: 'Passeport',
    checkinDate: 'Date d\'Arrivée',
    checkoutDate: 'Date de Départ',
    roomType: 'Type de Chambre',
    standard: 'Standard',
    deluxe: 'Deluxe',
    suite: 'Suite',
    paymentMethod: 'Méthode de Paiement',
    mobileMoneyMTN: 'Mobile Money (MTN)',
    mobileMoneyOrange: 'Mobile Money (Orange)',
    creditCard: 'Carte de Crédit',
    cash: 'Espèces',
    
    // Admin
    resourceAllocation: 'Allocation des Ressources',
    roomInventory: 'Inventaire des Chambres',
    eventCalendar: 'Calendrier des Événements',
    staffRoles: 'Rôles du Personnel',
    
    // Status
    occupied: 'Occupé',
    available: 'Disponible',
    maintenance: 'Maintenance',
    clean: 'Propre',
    
    // Currency
    fcfa: 'FCFA',
    
    // Special
    visaAssistance: 'Assistance Visa',
    airportPickup: 'Navette Aéroport',
    tourismTax: 'Taxe de Tourisme',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};