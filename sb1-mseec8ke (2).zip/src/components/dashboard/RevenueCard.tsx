import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { TrendingUp } from 'lucide-react';

interface RevenueData {
  facility: string;
  amount: number;
  color: string;
}

interface RevenueCardProps {
  data: RevenueData[];
}

const RevenueCard: React.FC<RevenueCardProps> = ({ data }) => {
  const { t } = useLanguage();

  const getColorClass = (color: string) => {
    const colors = {
      green: 'bg-green-500',
      yellow: 'bg-yellow-500',
      red: 'bg-red-500',
      blue: 'bg-blue-500',
    };
    return colors[color as keyof typeof colors] || 'bg-gray-500';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">{t('revenueBreakdown')}</h3>
        <TrendingUp className="h-5 w-5 text-green-600" />
      </div>
      
      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${getColorClass(item.color)}`} />
              <span className="font-medium text-gray-900">{item.facility}</span>
            </div>
            <div className="text-right">
              <p className="font-bold text-gray-900">
                {item.amount.toLocaleString()} {t('fcfa')}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RevenueCard;