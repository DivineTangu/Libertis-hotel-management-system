import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

interface OccupancyData {
  facility: string;
  occupied: number;
  total: number;
  percentage: number;
}

interface OccupancyCardProps {
  data: OccupancyData[];
}

const OccupancyCard: React.FC<OccupancyCardProps> = ({ data }) => {
  const { t } = useLanguage();

  const getStatusColor = (percentage: number) => {
    if (percentage >= 80) return 'bg-red-500';
    if (percentage >= 60) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-xl font-bold text-gray-900 mb-6">{t('liveOccupancy')}</h3>
      
      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-gray-900">{item.facility}</span>
              <span className="text-sm font-bold text-gray-700">
                {item.occupied}/{item.total}
              </span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all duration-300 ${getStatusColor(item.percentage)}`}
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
              <span className="text-sm font-medium text-gray-600">
                {item.percentage}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OccupancyCard;