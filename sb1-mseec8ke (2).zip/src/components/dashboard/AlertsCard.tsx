import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Bell, Clock } from 'lucide-react';

interface AlertData {
  type: string;
  count: number;
  time: string;
}

interface AlertsCardProps {
  data: AlertData[];
}

const AlertsCard: React.FC<AlertsCardProps> = ({ data }) => {
  const { t } = useLanguage();

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">{t('todayAlerts')}</h3>
        <Bell className="h-5 w-5 text-yellow-600" />
      </div>
      
      <div className="space-y-4">
        {data.map((item, index) => (
          <div key={index} className="border-l-4 border-yellow-500 bg-yellow-50 p-4 rounded-r-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-900">{item.type}</p>
                <p className="text-2xl font-bold text-yellow-700">{item.count}</p>
              </div>
              <div className="text-right text-gray-600">
                <Clock className="h-4 w-4 inline mr-1" />
                <span className="text-sm">{item.time}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AlertsCard;