import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Users, Mic, Camera, Utensils } from 'lucide-react';

const EventBooking: React.FC = () => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    eventName: '',
    eventType: 'wedding',
    date: '',
    time: '',
    duration: '4',
    guests: '100',
    catering: false,
    equipment: [],
  });

  const eventTypes = [
    { id: 'wedding', label: 'Wedding', price: 500000 },
    { id: 'conference', label: 'Conference', price: 300000 },
    { id: 'party', label: 'Party', price: 250000 },
    { id: 'corporate', label: 'Corporate Event', price: 400000 },
  ];

  const equipment = [
    { id: 'projector', label: 'Projector & Screen', price: 25000 },
    { id: 'sound', label: 'Sound System', price: 35000 },
    { id: 'stage', label: 'Stage Setup', price: 75000 },
    { id: 'lighting', label: 'Professional Lighting', price: 45000 },
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleEquipmentChange = (equipmentId: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      equipment: checked 
        ? [...prev.equipment, equipmentId]
        : prev.equipment.filter(id => id !== equipmentId)
    }));
  };

  const calculateTotal = () => {
    const eventPrice = eventTypes.find(type => type.id === formData.eventType)?.price || 0;
    const equipmentTotal = formData.equipment.reduce((total, equipId) => {
      const item = equipment.find(e => e.id === equipId);
      return total + (item?.price || 0);
    }, 0);
    const cateringPrice = formData.catering ? parseInt(formData.guests) * 15000 : 0;
    return eventPrice + equipmentTotal + cateringPrice;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Event Details Form */}
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Event Details</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Event Name
              </label>
              <input
                type="text"
                value={formData.eventName}
                onChange={(e) => handleInputChange('eventName', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder="Enter event name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Event Type
              </label>
              <select
                value={formData.eventType}
                onChange={(e) => handleInputChange('eventType', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                {eventTypes.map((type) => (
                  <option key={type.id} value={type.id}>
                    {type.label} - {type.price.toLocaleString()} {t('fcfa')}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date
                </label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Time
                </label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => handleInputChange('time', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration (hours)
                </label>
                <input
                  type="number"
                  value={formData.duration}
                  onChange={(e) => handleInputChange('duration', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  min="1"
                  max="12"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Users className="h-4 w-4 inline mr-1" />
                  Number of Guests
                </label>
                <input
                  type="number"
                  value={formData.guests}
                  onChange={(e) => handleInputChange('guests', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  min="10"
                  max="500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Equipment & Services */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Additional Equipment</h3>
          <div className="space-y-3">
            {equipment.map((item) => {
              const icons = {
                projector: Camera,
                sound: Mic,
                stage: Users,
                lighting: Mic,
              };
              const Icon = icons[item.id as keyof typeof icons] || Mic;
              
              return (
                <label key={item.id} className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="checkbox"
                    checked={formData.equipment.includes(item.id)}
                    onChange={(e) => handleEquipmentChange(item.id, e.target.checked)}
                    className="text-green-600 focus:ring-green-500"
                  />
                  <Icon className="h-5 w-5 ml-3 mr-2 text-gray-500" />
                  <div className="flex-1">
                    <span className="font-medium text-gray-900">{item.label}</span>
                    <span className="ml-2 text-green-600 font-semibold">
                      +{item.price.toLocaleString()} {t('fcfa')}
                    </span>
                  </div>
                </label>
              );
            })}
          </div>
        </div>

        {/* Catering */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Catering Services</h3>
          <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
            <input
              type="checkbox"
              checked={formData.catering}
              onChange={(e) => handleInputChange('catering', e.target.checked)}
              className="text-green-600 focus:ring-green-500"
            />
            <Utensils className="h-5 w-5 ml-3 mr-2 text-gray-500" />
            <div className="flex-1">
              <span className="font-medium text-gray-900">Full Catering Service</span>
              <span className="ml-2 text-green-600 font-semibold">
                15,000 {t('fcfa')}/person
              </span>
            </div>
          </label>
        </div>
      </div>

      {/* Event Summary */}
      <div className="space-y-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Event Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Event Hall</span>
              <span className="font-medium">
                {eventTypes.find(t => t.id === formData.eventType)?.price.toLocaleString()} {t('fcfa')}
              </span>
            </div>
            
            {formData.equipment.length > 0 && (
              <div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Equipment Rental</span>
                  <span className="font-medium">
                    {formData.equipment.reduce((total, equipId) => {
                      const item = equipment.find(e => e.id === equipId);
                      return total + (item?.price || 0);
                    }, 0).toLocaleString()} {t('fcfa')}
                  </span>
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {formData.equipment.map(equipId => {
                    const item = equipment.find(e => e.id === equipId);
                    return item?.label;
                  }).join(', ')}
                </div>
              </div>
            )}

            {formData.catering && (
              <div className="flex justify-between">
                <span className="text-gray-600">Catering ({formData.guests} guests)</span>
                <span className="font-medium">
                  {(parseInt(formData.guests) * 15000).toLocaleString()} {t('fcfa')}
                </span>
              </div>
            )}

            <div className="border-t pt-3">
              <div className="flex justify-between">
                <span className="text-lg font-semibold text-gray-900">Total</span>
                <span className="text-lg font-bold text-green-600">
                  {calculateTotal().toLocaleString()} {t('fcfa')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Book Button */}
        <button className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-colors">
          Book Event Hall
        </button>
      </div>
    </div>
  );
};

export default EventBooking;