import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Waves, Dumbbell, Clock, User, UserCheck } from 'lucide-react';

const AmenitiesBooking: React.FC = () => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('pool');
  const [formData, setFormData] = useState({
    guestType: 'hotel',
    name: '',
    phone: '',
    date: '',
    timeSlot: '',
    duration: '2',
    equipment: [],
  });

  const amenities = [
    { id: 'pool', label: 'Pool Access', icon: Waves, price: 5000 },
    { id: 'gym', label: 'Gym Access', icon: Dumbbell, price: 3000 },
  ];

  const timeSlots = [
    '06:00 - 08:00', '08:00 - 10:00', '10:00 - 12:00',
    '12:00 - 14:00', '14:00 - 16:00', '16:00 - 18:00',
    '18:00 - 20:00', '20:00 - 22:00'
  ];

  const gymEquipment = [
    { id: 'trainer', label: 'Personal Trainer', price: 15000 },
    { id: 'locker', label: 'Premium Locker', price: 1000 },
    { id: 'towel', label: 'Towel Service', price: 500 },
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleEquipmentChange = (equipmentId: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      equipment: checked 
        ? [...prev.equipment, equipmentId]
        : prev.equipment.filter(id => id !== equipmentId)
    }));
  };

  const calculateTotal = () => {
    const selectedAmenity = amenities.find(a => a.id === activeTab);
    const basePrice = selectedAmenity?.price || 0;
    const duration = parseInt(formData.duration);
    const equipmentTotal = formData.equipment.reduce((total, equipId) => {
      const item = gymEquipment.find(e => e.id === equipId);
      return total + (item?.price || 0);
    }, 0);
    
    const durationMultiplier = activeTab === 'pool' ? duration * 0.5 : duration;
    return (basePrice * durationMultiplier) + equipmentTotal;
  };

  return (
    <div className="space-y-8">
      {/* Amenity Tabs */}
      <div className="flex space-x-4">
        {amenities.map((amenity) => {
          const Icon = amenity.icon;
          return (
            <button
              key={amenity.id}
              onClick={() => setActiveTab(amenity.id)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-colors ${
                activeTab === amenity.id
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span>{amenity.label}</span>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Booking Form */}
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {amenities.find(a => a.id === activeTab)?.label} Booking
            </h3>
            
            {/* Guest Type */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Guest Type
              </label>
              <div className="flex space-x-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="guestType"
                    value="hotel"
                    checked={formData.guestType === 'hotel'}
                    onChange={(e) => handleInputChange('guestType', e.target.value)}
                    className="text-green-600 focus:ring-green-500"
                  />
                  <UserCheck className="h-4 w-4 ml-2 mr-1 text-gray-500" />
                  <span className="text-gray-900">Hotel Guest</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="guestType"
                    value="external"
                    checked={formData.guestType === 'external'}
                    onChange={(e) => handleInputChange('guestType', e.target.value)}
                    className="text-green-600 focus:ring-green-500"
                  />
                  <User className="h-4 w-4 ml-2 mr-1 text-gray-500" />
                  <span className="text-gray-900">External Guest</span>
                </label>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Guest name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="+237 xxx xxx xxx"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Date
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Clock className="h-4 w-4 inline mr-1" />
                    Time Slot
                  </label>
                  <select
                    value={formData.timeSlot}
                    onChange={(e) => handleInputChange('timeSlot', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select time slot</option>
                    {timeSlots.map((slot, index) => (
                      <option key={index} value={slot}>{slot}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration (hours)
                </label>
                <select
                  value={formData.duration}
                  onChange={(e) => handleInputChange('duration', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="1">1 hour</option>
                  <option value="2">2 hours</option>
                  <option value="3">3 hours</option>
                  <option value="4">4 hours</option>
                  <option value="8">Full day</option>
                </select>
              </div>
            </div>
          </div>

          {/* Additional Services for Gym */}
          {activeTab === 'gym' && (
            <div>
              <h4 className="text-md font-semibold text-gray-900 mb-4">Additional Services</h4>
              <div className="space-y-3">
                {gymEquipment.map((item) => (
                  <label key={item.id} className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="checkbox"
                      checked={formData.equipment.includes(item.id)}
                      onChange={(e) => handleEquipmentChange(item.id, e.target.checked)}
                      className="text-green-600 focus:ring-green-500"
                    />
                    <div className="ml-3 flex-1">
                      <span className="font-medium text-gray-900">{item.label}</span>
                      <span className="ml-2 text-green-600 font-semibold">
                        +{item.price.toLocaleString()} {t('fcfa')}
                      </span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}

          <button className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-colors">
            Book {amenities.find(a => a.id === activeTab)?.label}
          </button>
        </div>

        {/* Amenity Info & Pricing */}
        <div className="space-y-6">
          {/* Facility Info */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {activeTab === 'pool' ? 'Pool Information' : 'Gym Information'}
            </h3>
            {activeTab === 'pool' && (
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Operating Hours</span>
                  <span className="font-medium">6:00 AM - 10:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Capacity</span>
                  <span className="font-medium">50 guests</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Temperature</span>
                  <span className="font-medium">28°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Depth</span>
                  <span className="font-medium">1.2m - 2.5m</span>
                </div>
              </div>
            )}
            {activeTab === 'gym' && (
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Operating Hours</span>
                  <span className="font-medium">5:00 AM - 11:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Equipment</span>
                  <span className="font-medium">Modern fitness equipment</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Air Conditioning</span>
                  <span className="font-medium">Yes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Changing Rooms</span>
                  <span className="font-medium">Available</span>
                </div>
              </div>
            )}
          </div>

          {/* Pricing Summary */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Pricing Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">
                  {formData.guestType === 'hotel' ? 'Hotel Guest Rate' : 'External Guest Rate'}
                </span>
                <span className="font-medium">
                  {(amenities.find(a => a.id === activeTab)?.price || 0).toLocaleString()} {t('fcfa')}/hour
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Duration</span>
                <span className="font-medium">{formData.duration} hour{parseInt(formData.duration) > 1 ? 's' : ''}</span>
              </div>

              {formData.equipment.length > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Additional Services</span>
                  <span className="font-medium">
                    {formData.equipment.reduce((total, equipId) => {
                      const item = gymEquipment.find(e => e.id === equipId);
                      return total + (item?.price || 0);
                    }, 0).toLocaleString()} {t('fcfa')}
                  </span>
                </div>
              )}

              <div className="border-t pt-3">
                <div className="flex justify-between">
                  <span className="text-lg font-semibold text-gray-900">Total</span>
                  <span className="text-lg font-bold text-green-600">
                    {calculateTotal().toLocaleString()} {t('fcfa')}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Current Status */}
          <div className="bg-green-50 rounded-lg p-4">
            <h4 className="font-semibold text-green-800 mb-2">Current Status</h4>
            <div className="text-sm text-green-700">
              {activeTab === 'pool' ? (
                <div>
                  <p>Pool is open and available</p>
                  <p>Current occupancy: 15/50 guests</p>
                </div>
              ) : (
                <div>
                  <p>Gym is open and available</p>
                  <p>Current occupancy: 8/20 guests</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AmenitiesBooking;