import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { CreditCard, Smartphone, Banknote, Plane, HelpCircle } from 'lucide-react';

const RoomBooking: React.FC = () => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    passport: '',
    checkinDate: '',
    checkoutDate: '',
    roomType: 'standard',
    paymentMethod: 'mtn',
    visaAssistance: false,
    airportPickup: false,
  });

  const roomTypes = [
    { id: 'standard', label: t('standard'), price: 45000 },
    { id: 'deluxe', label: t('deluxe'), price: 75000 },
    { id: 'suite', label: t('suite'), price: 120000 },
  ];

  const paymentMethods = [
    { id: 'mtn', label: t('mobileMoneyMTN'), icon: Smartphone },
    { id: 'orange', label: t('mobileMoneyOrange'), icon: Smartphone },
    { id: 'card', label: t('creditCard'), icon: CreditCard },
    { id: 'cash', label: t('cash'), icon: Banknote },
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateTotal = () => {
    const selectedRoom = roomTypes.find(room => room.id === formData.roomType);
    const basePrice = selectedRoom?.price || 0;
    const vat = basePrice * 0.1925; // 19.25% VAT
    const tourismTax = 2500; // Fixed tourism tax
    return basePrice + vat + tourismTax;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Guest Details Form */}
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">{t('guestDetails')}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('name')}
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder="Full Name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('phone')}
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder="+237 xxx xxx xxx"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('email')}
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder="email@example.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('passport')}
              </label>
              <input
                type="text"
                value={formData.passport}
                onChange={(e) => handleInputChange('passport', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder="Passport Number"
              />
            </div>
          </div>
        </div>

        {/* Dates */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Stay Dates</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('checkinDate')}
              </label>
              <input
                type="date"
                value={formData.checkinDate}
                onChange={(e) => handleInputChange('checkinDate', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('checkoutDate')}
              </label>
              <input
                type="date"
                value={formData.checkoutDate}
                onChange={(e) => handleInputChange('checkoutDate', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </div>

        {/* Room Type */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">{t('roomType')}</h3>
          <div className="space-y-3">
            {roomTypes.map((room) => (
              <label key={room.id} className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="roomType"
                  value={room.id}
                  checked={formData.roomType === room.id}
                  onChange={(e) => handleInputChange('roomType', e.target.value)}
                  className="text-green-600 focus:ring-green-500"
                />
                <div className="ml-3 flex-1">
                  <span className="font-medium text-gray-900">{room.label}</span>
                  <span className="ml-2 text-green-600 font-semibold">
                    {room.price.toLocaleString()} {t('fcfa')}/night
                  </span>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Special Services */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Special Services</h3>
          <div className="space-y-3">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.visaAssistance}
                onChange={(e) => handleInputChange('visaAssistance', e.target.checked)}
                className="text-green-600 focus:ring-green-500"
              />
              <HelpCircle className="h-5 w-5 ml-2 mr-1 text-gray-500" />
              <span className="text-gray-700">{t('visaAssistance')}</span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.airportPickup}
                onChange={(e) => handleInputChange('airportPickup', e.target.checked)}
                className="text-green-600 focus:ring-green-500"
              />
              <Plane className="h-5 w-5 ml-2 mr-1 text-gray-500" />
              <span className="text-gray-700">{t('airportPickup')}</span>
            </label>
          </div>
        </div>
      </div>

      {/* Payment & Summary */}
      <div className="space-y-6">
        {/* Payment Method */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">{t('paymentMethod')}</h3>
          <div className="space-y-3">
            {paymentMethods.map((method) => {
              const Icon = method.icon;
              return (
                <label key={method.id} className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value={method.id}
                    checked={formData.paymentMethod === method.id}
                    onChange={(e) => handleInputChange('paymentMethod', e.target.value)}
                    className="text-green-600 focus:ring-green-500"
                  />
                  <Icon className="h-5 w-5 ml-3 mr-2 text-gray-500" />
                  <span className="text-gray-900">{method.label}</span>
                </label>
              );
            })}
          </div>
        </div>

        {/* Booking Summary */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Room Rate</span>
              <span className="font-medium">
                {roomTypes.find(r => r.id === formData.roomType)?.price.toLocaleString()} {t('fcfa')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">VAT (19.25%)</span>
              <span className="font-medium">
                {Math.round((roomTypes.find(r => r.id === formData.roomType)?.price || 0) * 0.1925).toLocaleString()} {t('fcfa')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">{t('tourismTax')}</span>
              <span className="font-medium">2,500 {t('fcfa')}</span>
            </div>
            <div className="border-t pt-3">
              <div className="flex justify-between">
                <span className="text-lg font-semibold text-gray-900">Total</span>
                <span className="text-lg font-bold text-green-600">
                  {calculateTotal().toLocaleString()} {t('fcfa')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Book Button */}
        <button className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-colors">
          Complete Booking
        </button>
      </div>
    </div>
  );
};

export default RoomBooking;