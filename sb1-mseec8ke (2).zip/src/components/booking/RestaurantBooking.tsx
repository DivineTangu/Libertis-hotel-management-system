import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Clock, Users, MapPin } from 'lucide-react';

const RestaurantBooking: React.FC = () => {
  const { t } = useLanguage();
  const [bookingType, setBookingType] = useState('reservation');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    date: '',
    time: '',
    guests: '2',
    tablePreference: 'any',
    specialRequests: '',
  });

  const tableTypes = [
    { id: 'any', label: 'Any Available Table', icon: MapPin },
    { id: 'window', label: 'Window Table', icon: MapPin },
    { id: 'terrace', label: 'Terrace Seating', icon: MapPin },
    { id: 'private', label: 'Private Dining Room', icon: MapPin },
  ];

  const popularDishes = [
    { name: 'Ndolé', price: 4500, description: 'Traditional Cameroonian stew with groundnuts' },
    { name: 'Poulet DG', price: 6500, description: 'Grilled chicken with plantains and vegetables' },
    { name: 'Jollof Rice', price: 3500, description: 'Spiced rice with tomatoes and peppers' },
    { name: 'Fish & Chips', price: 5500, description: 'Fresh fish with seasoned fries' },
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-8">
      {/* Booking Type Toggle */}
      <div className="flex space-x-4">
        <button
          onClick={() => setBookingType('reservation')}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            bookingType === 'reservation'
              ? 'bg-green-600 text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          Table Reservation
        </button>
        <button
          onClick={() => setBookingType('walkin')}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            bookingType === 'walkin'
              ? 'bg-green-600 text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          Walk-in Management
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Reservation Form */}
        <div className="space-y-6">
          {bookingType === 'reservation' && (
            <>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Reservation Details</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Name
                      </label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                        placeholder="Guest name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Phone
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                        placeholder="+237 xxx xxx xxx"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Date
                      </label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => handleInputChange('date', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Clock className="h-4 w-4 inline mr-1" />
                        Time
                      </label>
                      <select
                        value={formData.time}
                        onChange={(e) => handleInputChange('time', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      >
                        <option value="">Select time</option>
                        <option value="12:00">12:00 PM</option>
                        <option value="12:30">12:30 PM</option>
                        <option value="13:00">1:00 PM</option>
                        <option value="13:30">1:30 PM</option>
                        <option value="19:00">7:00 PM</option>
                        <option value="19:30">7:30 PM</option>
                        <option value="20:00">8:00 PM</option>
                        <option value="20:30">8:30 PM</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Users className="h-4 w-4 inline mr-1" />
                        Guests
                      </label>
                      <select
                        value={formData.guests}
                        onChange={(e) => handleInputChange('guests', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      >
                        {[1,2,3,4,5,6,7,8,9,10].map(num => (
                          <option key={num} value={num}>{num} guest{num > 1 ? 's' : ''}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Table Preference
                    </label>
                    <div className="space-y-2">
                      {tableTypes.map((table) => {
                        const Icon = table.icon;
                        return (
                          <label key={table.id} className="flex items-center p-2 border rounded-md cursor-pointer hover:bg-gray-50">
                            <input
                              type="radio"
                              name="tablePreference"
                              value={table.id}
                              checked={formData.tablePreference === table.id}
                              onChange={(e) => handleInputChange('tablePreference', e.target.value)}
                              className="text-green-600 focus:ring-green-500"
                            />
                            <Icon className="h-4 w-4 ml-2 mr-1 text-gray-500" />
                            <span className="text-gray-900">{table.label}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Special Requests
                    </label>
                    <textarea
                      value={formData.specialRequests}
                      onChange={(e) => handleInputChange('specialRequests', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      rows={3}
                      placeholder="Any dietary restrictions, celebration details, etc."
                    />
                  </div>
                </div>
              </div>

              <button className="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                Make Reservation
              </button>
            </>
          )}

          {bookingType === 'walkin' && (
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Walk-in Management</h3>
              <p className="text-gray-600 mb-6">
                Manage walk-in guests and table availability in real-time
              </p>
              <div className="grid grid-cols-2 gap-4">
                <button className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors">
                  Seat Walk-in
                </button>
                <button className="bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">
                  View Queue
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Menu Preview */}
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Dishes</h3>
            <div className="space-y-4">
              {popularDishes.map((dish, index) => (
                <div key={index} className="bg-white border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-gray-900">{dish.name}</h4>
                    <span className="font-bold text-green-600">
                      {dish.price.toLocaleString()} {t('fcfa')}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{dish.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Table Status */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Table Availability</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">12</div>
                <div className="text-sm text-gray-600">Available</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">18</div>
                <div className="text-sm text-gray-600">Occupied</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantBooking;