import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Bed, Users, Utensils, Waves, Wrench, CheckCircle, AlertTriangle } from 'lucide-react';

const LiveHotelMap: React.FC = () => {
  const [selectedFloor, setSelectedFloor] = useState(1);
  const [selectedView, setSelectedView] = useState('rooms');

  const floors = [1, 2, 3];
  const views = [
    { id: 'rooms', label: 'Rooms', icon: Bed },
    { id: 'events', label: 'Events', icon: Users },
    { id: 'restaurant', label: 'Restaurant', icon: Utensils },
    { id: 'amenities', label: 'Amenities', icon: Waves }
  ];

  // Mock room data
  const rooms = Array.from({ length: 20 }, (_, i) => ({
    number: `${selectedFloor}${(i + 1).toString().padStart(2, '0')}`,
    status: Math.random() > 0.6 ? 'occupied' : Math.random() > 0.3 ? 'clean' : 'maintenance',
    guest: Math.random() > 0.6 ? `Guest ${i + 1}` : null,
    type: ['standard', 'deluxe', 'suite'][Math.floor(Math.random() * 3)]
  }));

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'occupied': return 'bg-red-500 border-red-400';
      case 'clean': return 'bg-emerald-500 border-emerald-400';
      case 'maintenance': return 'bg-yellow-500 border-yellow-400';
      default: return 'bg-gray-500 border-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'occupied': return <AlertTriangle className="h-3 w-3" />;
      case 'clean': return <CheckCircle className="h-3 w-3" />;
      case 'maintenance': return <Wrench className="h-3 w-3" />;
      default: return <CheckCircle className="h-3 w-3" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6 }}
      className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 p-6 shadow-2xl"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold text-white">Live Hotel Map</h3>
        
        {/* View Toggle */}
        <div className="flex space-x-2">
          {views.map((view) => {
            const Icon = view.icon;
            return (
              <button
                key={view.id}
                onClick={() => setSelectedView(view.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
                  selectedView === view.id
                    ? 'bg-emerald-600 text-white'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="text-sm font-medium">{view.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {selectedView === 'rooms' && (
        <>
          {/* Floor Selection */}
          <div className="flex space-x-2 mb-6">
            {floors.map((floor) => (
              <button
                key={floor}
                onClick={() => setSelectedFloor(floor)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  selectedFloor === floor
                    ? 'bg-blue-600 text-white'
                    : 'bg-white/10 text-gray-300 hover:bg-white/20'
                }`}
              >
                Floor {floor}
              </button>
            ))}
          </div>

          {/* Room Grid */}
          <div className="grid grid-cols-5 gap-3 mb-6">
            {rooms.map((room) => (
              <motion.div
                key={room.number}
                whileHover={{ scale: 1.05 }}
                className={`relative p-3 rounded-lg border-2 cursor-pointer transition-all ${getStatusColor(room.status)}`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-white font-bold text-sm">{room.number}</span>
                  {getStatusIcon(room.status)}
                </div>
                <div className="text-xs text-white/80 capitalize">{room.type}</div>
                {room.guest && (
                  <div className="text-xs text-white/60 truncate mt-1">{room.guest}</div>
                )}
              </motion.div>
            ))}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded border border-red-400"></div>
              <span className="text-gray-300">Occupied</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-emerald-500 rounded border border-emerald-400"></div>
              <span className="text-gray-300">Available</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded border border-yellow-400"></div>
              <span className="text-gray-300">Maintenance</span>
            </div>
          </div>
        </>
      )}

      {selectedView === 'restaurant' && (
        <div className="space-y-6">
          <div className="grid grid-cols-6 gap-2">
            {Array.from({ length: 30 }, (_, i) => (
              <div
                key={i}
                className={`p-2 text-center text-xs rounded-md border ${
                  Math.random() > 0.6 
                    ? 'bg-red-500/20 border-red-400 text-red-300' 
                    : 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                }`}
              >
                <div className="font-medium">T{(i + 1).toString().padStart(2, '0')}</div>
                <div className="text-xs opacity-75">{Math.floor(Math.random() * 6) + 2}p</div>
              </div>
            ))}
          </div>
          
          <div className="flex items-center justify-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-emerald-500/20 border border-emerald-400 rounded"></div>
              <span className="text-gray-300">Available</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500/20 border border-red-400 rounded"></div>
              <span className="text-gray-300">Occupied</span>
            </div>
          </div>
        </div>
      )}

      {selectedView === 'amenities' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-500/20 p-4 rounded-xl border border-blue-400/30">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-blue-300">Swimming Pool</span>
                <span className="text-sm text-blue-400">30% Capacity</span>
              </div>
              <div className="w-full bg-blue-900/50 rounded-full h-3">
                <div className="bg-blue-500 h-3 rounded-full" style={{ width: '30%' }}></div>
              </div>
              <div className="text-sm text-blue-400 mt-2">15/50 guests</div>
            </div>
            
            <div className="bg-purple-500/20 p-4 rounded-xl border border-purple-400/30">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-purple-300">Fitness Center</span>
                <span className="text-sm text-purple-400">40% Capacity</span>
              </div>
              <div className="w-full bg-purple-900/50 rounded-full h-3">
                <div className="bg-purple-500 h-3 rounded-full" style={{ width: '40%' }}></div>
              </div>
              <div className="text-sm text-purple-400 mt-2">8/20 guests</div>
            </div>
          </div>
        </div>
      )}

      {selectedView === 'events' && (
        <div className="space-y-4">
          {[
            { hall: 'Grand Hall', event: 'Wedding Reception', capacity: '200/300', status: 'active' },
            { hall: 'Conference Room A', event: 'Business Meeting', capacity: '25/50', status: 'setup' },
            { hall: 'Garden Terrace', event: 'Birthday Party', capacity: '30/80', status: 'ready' }
          ].map((event, index) => (
            <div key={index} className="bg-white/5 p-4 rounded-xl border border-white/10">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium text-white">{event.hall}</h4>
                  <p className="text-sm text-gray-400">{event.event}</p>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-300">{event.capacity}</div>
                  <div className={`text-xs px-2 py-1 rounded-full ${
                    event.status === 'active' ? 'bg-green-500/20 text-green-400' :
                    event.status === 'setup' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {event.status}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
};

export default LiveHotelMap;