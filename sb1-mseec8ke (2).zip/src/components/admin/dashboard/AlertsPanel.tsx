import React from 'react';
import { motion } from 'framer-motion';
import { Bell, Clock, AlertTriangle, CheckCircle, Users, Calendar } from 'lucide-react';

const AlertsPanel: React.FC = () => {
  const alerts = [
    {
      id: 1,
      type: 'checkin',
      title: 'Upcoming Check-ins',
      message: '12 guests checking in at 2:00 PM',
      time: '1 hour',
      priority: 'medium',
      icon: Users
    },
    {
      id: 2,
      type: 'maintenance',
      title: 'Room 203 Maintenance',
      message: 'AC unit requires immediate attention',
      time: '30 minutes',
      priority: 'high',
      icon: AlertTriangle
    },
    {
      id: 3,
      type: 'event',
      title: 'Wedding Setup',
      message: 'Grand Hall preparation starts in 2 hours',
      time: '2 hours',
      priority: 'medium',
      icon: Calendar
    },
    {
      id: 4,
      type: 'checkout',
      title: 'Late Checkout Request',
      message: 'Suite 301 requests 3 PM checkout',
      time: '45 minutes',
      priority: 'low',
      icon: Clock
    },
    {
      id: 5,
      type: 'completed',
      title: 'Pool Cleaning Complete',
      message: 'Daily maintenance finished successfully',
      time: 'Just now',
      priority: 'info',
      icon: CheckCircle
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-red-500 bg-red-500/10';
      case 'medium': return 'border-yellow-500 bg-yellow-500/10';
      case 'low': return 'border-blue-500 bg-blue-500/10';
      case 'info': return 'border-emerald-500 bg-emerald-500/10';
      default: return 'border-gray-500 bg-gray-500/10';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-blue-400';
      case 'info': return 'text-emerald-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6 }}
      className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 p-6 shadow-2xl h-fit"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-r from-yellow-600 to-orange-600 p-3 rounded-xl">
            <Bell className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">Live Alerts</h3>
            <p className="text-gray-400">Real-time notifications</p>
          </div>
        </div>
        
        <div className="relative">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
        </div>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {alerts.map((alert, index) => {
          const Icon = alert.icon;
          
          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className={`border-l-4 rounded-r-xl p-4 cursor-pointer hover:bg-white/5 transition-all ${getPriorityColor(alert.priority)}`}
            >
              <div className="flex items-start space-x-3">
                <Icon className={`h-5 w-5 mt-0.5 ${getPriorityIcon(alert.priority)}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-white text-sm">{alert.title}</h4>
                    <span className="text-xs text-gray-400">{alert.time}</span>
                  </div>
                  <p className="text-gray-300 text-sm leading-relaxed">{alert.message}</p>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <h4 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
          Quick Actions
        </h4>
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-white/10 hover:bg-white/20 p-3 rounded-lg text-center transition-colors">
            <Users className="h-5 w-5 text-white mx-auto mb-1" />
            <span className="text-xs text-gray-300">Check-ins</span>
          </button>
          <button className="bg-white/10 hover:bg-white/20 p-3 rounded-lg text-center transition-colors">
            <Calendar className="h-5 w-5 text-white mx-auto mb-1" />
            <span className="text-xs text-gray-300">Events</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default AlertsPanel;