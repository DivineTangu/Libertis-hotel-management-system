import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, DollarSign, Users, Bed, Calendar } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';

const KPICards: React.FC = () => {
  const { t } = useLanguage();

  const kpis = [
    {
      title: 'Total Revenue',
      value: '4,105,000',
      unit: 'FCFA',
      change: '+12.5%',
      trend: 'up',
      icon: DollarSign,
      color: 'from-emerald-600 to-emerald-700'
    },
    {
      title: 'Occupancy Rate',
      value: '72',
      unit: '%',
      change: '+5.2%',
      trend: 'up',
      icon: Bed,
      color: 'from-blue-600 to-blue-700'
    },
    {
      title: 'Active Guests',
      value: '156',
      unit: 'guests',
      change: '-2.1%',
      trend: 'down',
      icon: Users,
      color: 'from-purple-600 to-purple-700'
    },
    {
      title: 'Events Today',
      value: '8',
      unit: 'events',
      change: '+25.0%',
      trend: 'up',
      icon: Calendar,
      color: 'from-red-600 to-red-700'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {kpis.map((kpi, index) => {
        const Icon = kpi.icon;
        const TrendIcon = kpi.trend === 'up' ? TrendingUp : TrendingDown;
        const trendColor = kpi.trend === 'up' ? 'text-emerald-400' : 'text-red-400';
        
        return (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            whileHover={{ scale: 1.02, y: -5 }}
            className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 p-6 shadow-2xl"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`bg-gradient-to-r ${kpi.color} p-3 rounded-xl shadow-lg`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
              <div className={`flex items-center space-x-1 ${trendColor}`}>
                <TrendIcon className="h-4 w-4" />
                <span className="text-sm font-medium">{kpi.change}</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-3xl font-bold text-white mb-1">
                {kpi.value}
                <span className="text-lg font-normal text-gray-400 ml-1">{kpi.unit}</span>
              </h3>
              <p className="text-gray-300 text-sm">{kpi.title}</p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default KPICards;