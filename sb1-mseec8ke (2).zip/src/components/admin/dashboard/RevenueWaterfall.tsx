import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, DollarSign } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';

const RevenueWaterfall: React.FC = () => {
  const { t } = useLanguage();

  const revenueData = [
    { category: 'Rooms', amount: 2850000, color: 'bg-emerald-500' },
    { category: 'Events', amount: 750000, color: 'bg-red-500' },
    { category: 'Restaurant', amount: 420000, color: 'bg-yellow-500' },
    { category: 'Amenities', amount: 85000, color: 'bg-blue-500' }
  ];

  const total = revenueData.reduce((sum, item) => sum + item.amount, 0);
  const maxAmount = Math.max(...revenueData.map(item => item.amount));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 p-6 shadow-2xl"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 p-3 rounded-xl">
            <DollarSign className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">Revenue Waterfall</h3>
            <p className="text-gray-400">Today's earnings breakdown</p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-3xl font-bold text-white">
            {total.toLocaleString()} <span className="text-lg text-gray-400">FCFA</span>
          </div>
          <div className="flex items-center text-emerald-400 text-sm">
            <TrendingUp className="h-4 w-4 mr-1" />
            +12.5% vs yesterday
          </div>
        </div>
      </div>

      {/* Waterfall Chart */}
      <div className="space-y-4">
        {revenueData.map((item, index) => {
          const percentage = (item.amount / maxAmount) * 100;
          
          return (
            <motion.div
              key={item.category}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-white">{item.category}</span>
                <div className="text-right">
                  <span className="text-white font-bold">
                    {item.amount.toLocaleString()} FCFA
                  </span>
                  <div className="text-sm text-gray-400">
                    {((item.amount / total) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
              
              <div className="relative">
                <div className="w-full bg-white/10 rounded-full h-3">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 1, delay: index * 0.2 }}
                    className={`h-3 rounded-full ${item.color} shadow-lg`}
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Tax Compliance Module */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <h4 className="text-lg font-semibold text-white mb-4">Tax Compliance</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/5 p-4 rounded-xl">
            <div className="text-sm text-gray-400 mb-1">VAT (19.25%)</div>
            <div className="text-lg font-bold text-white">
              {Math.round(total * 0.1925).toLocaleString()} FCFA
            </div>
          </div>
          <div className="bg-white/5 p-4 rounded-xl">
            <div className="text-sm text-gray-400 mb-1">Tourism Tax</div>
            <div className="text-lg font-bold text-white">
              125,000 FCFA
            </div>
          </div>
          <div className="bg-white/5 p-4 rounded-xl">
            <div className="text-sm text-gray-400 mb-1">Net Revenue</div>
            <div className="text-lg font-bold text-emerald-400">
              {(total - Math.round(total * 0.1925) - 125000).toLocaleString()} FCFA
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default RevenueWaterfall;