import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Bed, Calendar, Utensils, Waves, CheckCircle, AlertTriangle, Wrench } from 'lucide-react';

const ResourceAllocation: React.FC = () => {
  const { t } = useLanguage();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const roomInventory = [
    { room: '101', type: 'Standard', status: 'occupied', guest: 'John Doe', checkout: '2025-01-15' },
    { room: '102', type: 'Standard', status: 'clean', guest: null, checkout: null },
    { room: '103', type: 'Deluxe', status: 'maintenance', guest: null, checkout: null },
    { room: '201', type: 'Suite', status: 'occupied', guest: 'Marie Martin', checkout: '2025-01-16' },
    { room: '202', type: 'Deluxe', status: 'clean', guest: null, checkout: null },
    { room: '203', type: 'Standard', status: 'occupied', guest: 'Ahmed Hassan', checkout: '2025-01-14' },
  ];

  const eventSchedule = [
    { time: '09:00', event: 'Corporate Meeting', hall: 'Main Hall', pax: 50, status: 'confirmed' },
    { time: '14:00', event: 'Wedding Reception', hall: 'Grand Hall', pax: 200, status: 'setup' },
    { time: '18:00', event: 'Birthday Party', hall: 'Garden Terrace', pax: 30, status: 'confirmed' },
  ];

  const restaurantTables = Array.from({ length: 30 }, (_, i) => ({
    table: `T${(i + 1).toString().padStart(2, '0')}`,
    seats: Math.floor(Math.random() * 6) + 2,
    status: Math.random() > 0.6 ? 'occupied' : 'available',
    server: Math.random() > 0.5 ? `Server ${Math.floor(Math.random() * 5) + 1}` : null,
  }));

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'occupied':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'clean':
      case 'available':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'maintenance':
      case 'setup':
        return <Wrench className="h-4 w-4 text-yellow-600" />;
      default:
        return <CheckCircle className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'occupied':
        return 'bg-red-100 text-red-800';
      case 'clean':
      case 'available':
        return 'bg-green-100 text-green-800';
      case 'maintenance':
      case 'setup':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-8">
      {/* Date Selector */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">Resource Overview</h3>
        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-gray-700">Date:</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Room Inventory */}
        <div className="bg-white rounded-lg border p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Bed className="h-5 w-5 text-green-600" />
            <h4 className="text-lg font-semibold text-gray-900">{t('roomInventory')}</h4>
          </div>
          <div className="space-y-3">
            {roomInventory.map((room, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(room.status)}
                  <div>
                    <span className="font-medium text-gray-900">Room {room.room}</span>
                    <span className="text-sm text-gray-500 ml-2">({room.type})</span>
                    {room.guest && (
                      <div className="text-xs text-gray-600">{room.guest}</div>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(room.status)}`}>
                    {t(room.status)}
                  </span>
                  {room.checkout && (
                    <div className="text-xs text-gray-500 mt-1">
                      Out: {room.checkout}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Event Calendar */}
        <div className="bg-white rounded-lg border p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Calendar className="h-5 w-5 text-green-600" />
            <h4 className="text-lg font-semibold text-gray-900">{t('eventCalendar')}</h4>
          </div>
          <div className="space-y-3">
            {eventSchedule.map((event, index) => (
              <div key={index} className="border rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">{event.event}</span>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(event.status)}`}>
                    {event.status}
                  </span>
                </div>
                <div className="text-sm text-gray-600">
                  <div>Time: {event.time}</div>
                  <div>Venue: {event.hall}</div>
                  <div>Guests: {event.pax} pax</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Restaurant Table Heatmap */}
        <div className="bg-white rounded-lg border p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Utensils className="h-5 w-5 text-green-600" />
            <h4 className="text-lg font-semibold text-gray-900">Restaurant Tables</h4>
          </div>
          <div className="grid grid-cols-6 gap-2">
            {restaurantTables.map((table, index) => (
              <div
                key={index}
                className={`p-2 text-center text-xs rounded-md border ${
                  table.status === 'occupied' 
                    ? 'bg-red-100 border-red-300 text-red-800' 
                    : 'bg-green-100 border-green-300 text-green-800'
                }`}
              >
                <div className="font-medium">{table.table}</div>
                <div className="text-xs opacity-75">{table.seats}p</div>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center space-x-6 mt-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-100 border border-green-300 rounded"></div>
              <span>Available</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-100 border border-red-300 rounded"></div>
              <span>Occupied</span>
            </div>
          </div>
        </div>

        {/* Pool & Amenities */}
        <div className="bg-white rounded-lg border p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Waves className="h-5 w-5 text-green-600" />
            <h4 className="text-lg font-semibold text-gray-900">Pool & Amenities</h4>
          </div>
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-blue-900">Swimming Pool</span>
                <span className="text-sm text-blue-700">30% Capacity</span>
              </div>
              <div className="w-full bg-blue-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '30%' }}></div>
              </div>
              <div className="text-sm text-blue-700 mt-2">
                Current: 15/50 guests
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-900">Fitness Center</span>
                <span className="text-sm text-gray-700">40% Capacity</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gray-600 h-2 rounded-full" style={{ width: '40%' }}></div>
              </div>
              <div className="text-sm text-gray-700 mt-2">
                Current: 8/20 guests
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="font-medium text-yellow-900">Maintenance Schedule</span>
                <Wrench className="h-4 w-4 text-yellow-600" />
              </div>
              <div className="text-sm text-yellow-700 mt-2">
                Pool cleaning: 6:00 AM daily<br />
                Gym equipment check: Weekly
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceAllocation;