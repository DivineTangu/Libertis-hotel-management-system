import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import AdminHeader from './AdminHeader';
import AdminSidebar from './AdminSidebar';
import ExecutiveDashboard from './ExecutiveDashboard';
import FacilityManagement from './FacilityManagement';
import StaffManagement from '../admin/StaffManagement';
import Analytics from '../admin/Analytics';

const AdminDashboard: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  if (!isAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-800">
      <AdminHeader sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      
      <div className="flex">
        <AdminSidebar isOpen={sidebarOpen} />
        
        <motion.main
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className={`flex-1 transition-all duration-300 ${
            sidebarOpen ? 'ml-64' : 'ml-16'
          } pt-16`}
        >
          <div className="p-6">
            <Routes>
              <Route path="/dashboard" element={<ExecutiveDashboard />} />
              <Route path="/facilities" element={<FacilityManagement />} />
              <Route path="/staff" element={<StaffManagement />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/" element={<Navigate to="/admin/dashboard" replace />} />
            </Routes>
          </div>
        </motion.main>
      </div>
    </div>
  );
};

export default AdminDashboard;