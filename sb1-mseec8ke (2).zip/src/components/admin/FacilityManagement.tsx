import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Bed, Users, Utensils, Waves, Calendar, Settings } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const FacilityManagement: React.FC = () => {
  const { t } = useLanguage();
  const [activeModule, setActiveModule] = useState('rooms');

  const modules = [
    {
      id: 'rooms',
      title: 'Room Management',
      description: 'Manage room inventory, housekeeping, and guest services',
      icon: Bed,
      color: 'from-emerald-600 to-emerald-700',
      features: ['Room Status', 'Housekeeping Schedule', 'Guest Requests', 'Maintenance Alerts']
    },
    {
      id: 'events',
      title: 'Event Management',
      description: 'Coordinate events, equipment, and catering services',
      icon: Users,
      color: 'from-red-600 to-red-700',
      features: ['Hall Planning', 'Equipment Inventory', 'Catering Links', 'Setup Scheduling']
    },
    {
      id: 'restaurant',
      title: 'F&B Management',
      description: 'Restaurant operations, menu management, and inventory',
      icon: Utensils,
      color: 'from-yellow-600 to-orange-600',
      features: ['Menu Designer', 'Table Management', 'Inventory Tracking', 'Room Charging']
    },
    {
      id: 'amenities',
      title: 'Amenities Management',
      description: 'Pool, gym, spa operations and maintenance scheduling',
      icon: Waves,
      color: 'from-blue-600 to-blue-700',
      features: ['Capacity Monitoring', 'Equipment Booking', 'Maintenance Schedule', 'Access Control']
    }
  ];

  const selectedModule = modules.find(m => m.id === activeModule);

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <h1 className="text-4xl font-bold text-white mb-4">
          Facility Management
        </h1>
        <p className="text-gray-300 text-lg">
          Comprehensive control over all hotel facilities and operations
        </p>
      </motion.div>

      {/* Module Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {modules.map((module, index) => {
          const Icon = module.icon;
          
          return (
            <motion.button
              key={module.id}
              onClick={() => setActiveModule(module.id)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
              className={`text-left p-6 rounded-2xl border-2 transition-all ${
                activeModule === module.id
                  ? `bg-gradient-to-br ${module.color} border-white/50 shadow-2xl`
                  : 'backdrop-blur-xl bg-white/10 border-white/20 hover:bg-white/20'
              }`}
            >
              <Icon className="h-8 w-8 text-white mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">{module.title}</h3>
              <p className="text-gray-300 text-sm leading-relaxed">{module.description}</p>
            </motion.button>
          );
        })}
      </div>

      {/* Selected Module Details */}
      {selectedModule && (
        <motion.div
          key={activeModule}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 p-8 shadow-2xl"
        >
          <div className="flex items-center space-x-4 mb-8">
            <div className={`bg-gradient-to-r ${selectedModule.color} p-4 rounded-2xl`}>
              <selectedModule.icon className="h-8 w-8 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white">{selectedModule.title}</h2>
              <p className="text-gray-300">{selectedModule.description}</p>
            </div>
          </div>

          {/* Feature Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {selectedModule.features.map((feature, index) => (
              <motion.div
                key={feature}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-white/5 p-4 rounded-xl border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-emerald-400 rounded-full"></div>
                  <span className="text-white font-medium">{feature}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Module-Specific Content */}
          {activeModule === 'rooms' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Room Status Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-emerald-500/20 p-6 rounded-xl border border-emerald-400/30">
                  <h4 className="text-emerald-300 font-semibold mb-2">Available Rooms</h4>
                  <div className="text-3xl font-bold text-white">28</div>
                  <div className="text-emerald-400 text-sm">Ready for guests</div>
                </div>
                <div className="bg-red-500/20 p-6 rounded-xl border border-red-400/30">
                  <h4 className="text-red-300 font-semibold mb-2">Occupied Rooms</h4>
                  <div className="text-3xl font-bold text-white">17</div>
                  <div className="text-red-400 text-sm">Currently in use</div>
                </div>
                <div className="bg-yellow-500/20 p-6 rounded-xl border border-yellow-400/30">
                  <h4 className="text-yellow-300 font-semibold mb-2">Maintenance</h4>
                  <div className="text-3xl font-bold text-white">3</div>
                  <div className="text-yellow-400 text-sm">Under maintenance</div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'events' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Event Hall Planner</h3>
              <div className="bg-white/5 p-6 rounded-xl">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-white font-semibold mb-3">Today's Events</h4>
                    <div className="space-y-3">
                      {[
                        { time: '09:00', event: 'Corporate Meeting', hall: 'Conference Room A' },
                        { time: '14:00', event: 'Wedding Reception', hall: 'Grand Hall' },
                        { time: '18:00', event: 'Birthday Party', hall: 'Garden Terrace' }
                      ].map((event, index) => (
                        <div key={index} className="bg-white/10 p-3 rounded-lg">
                          <div className="flex justify-between items-center">
                            <span className="text-white font-medium">{event.event}</span>
                            <span className="text-gray-400 text-sm">{event.time}</span>
                          </div>
                          <div className="text-gray-300 text-sm">{event.hall}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold mb-3">Equipment Status</h4>
                    <div className="space-y-2">
                      {[
                        { item: 'Projectors', available: 8, total: 10 },
                        { item: 'Sound Systems', available: 5, total: 6 },
                        { item: 'Stage Platforms', available: 3, total: 4 }
                      ].map((equipment, index) => (
                        <div key={index} className="flex justify-between items-center">
                          <span className="text-gray-300">{equipment.item}</span>
                          <span className="text-white">{equipment.available}/{equipment.total}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'restaurant' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Restaurant Operations</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/5 p-6 rounded-xl">
                  <h4 className="text-white font-semibold mb-3">Table Status</h4>
                  <div className="grid grid-cols-6 gap-2">
                    {Array.from({ length: 24 }, (_, i) => (
                      <div
                        key={i}
                        className={`p-2 text-center text-xs rounded ${
                          Math.random() > 0.6 
                            ? 'bg-red-500/20 text-red-300' 
                            : 'bg-emerald-500/20 text-emerald-300'
                        }`}
                      >
                        T{i + 1}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white/5 p-6 rounded-xl">
                  <h4 className="text-white font-semibold mb-3">Popular Dishes</h4>
                  <div className="space-y-2">
                    {[
                      { dish: 'Ndolé', orders: 12 },
                      { dish: 'Poulet DG', orders: 8 },
                      { dish: 'Jollof Rice', orders: 15 }
                    ].map((item, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-300">{item.dish}</span>
                        <span className="text-white">{item.orders} orders</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeModule === 'amenities' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Amenities Overview</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-500/20 p-6 rounded-xl border border-blue-400/30">
                  <h4 className="text-blue-300 font-semibold mb-3">Swimming Pool</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Current Capacity</span>
                      <span className="text-white">15/50 guests</span>
                    </div>
                    <div className="w-full bg-blue-900/50 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                    </div>
                    <div className="text-blue-400 text-sm">Next cleaning: 6:00 AM</div>
                  </div>
                </div>
                <div className="bg-purple-500/20 p-6 rounded-xl border border-purple-400/30">
                  <h4 className="text-purple-300 font-semibold mb-3">Fitness Center</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Current Capacity</span>
                      <span className="text-white">8/20 guests</span>
                    </div>
                    <div className="w-full bg-purple-900/50 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: '40%' }}></div>
                    </div>
                    <div className="text-purple-400 text-sm">Equipment check: Weekly</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-4 mt-8">
            <button className={`flex items-center space-x-2 px-6 py-3 bg-gradient-to-r ${selectedModule.color} text-white rounded-xl hover:shadow-lg transition-all`}>
              <Settings className="h-5 w-5" />
              <span>Configure {selectedModule.title}</span>
            </button>
            <button className="flex items-center space-x-2 px-6 py-3 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all">
              <Calendar className="h-5 w-5" />
              <span>Schedule Maintenance</span>
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default FacilityManagement;