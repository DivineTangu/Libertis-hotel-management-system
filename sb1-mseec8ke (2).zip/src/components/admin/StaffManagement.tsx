import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { User, Phone, Mail, MapPin, Clock, Star } from 'lucide-react';

const StaffManagement: React.FC = () => {
  const { t } = useLanguage();
  const [selectedDepartment, setSelectedDepartment] = useState('all');

  const departments = [
    { id: 'all', label: 'All Departments' },
    { id: 'reception', label: 'Reception' },
    { id: 'housekeeping', label: 'Housekeeping' },
    { id: 'fnb', label: 'Food & Beverage' },
    { id: 'events', label: 'Events' },
    { id: 'maintenance', label: 'Maintenance' },
  ];

  const staff = [
    {
      id: 1,
      name: 'Claire Dubois',
      role: 'Front Desk Manager',
      department: 'reception',
      phone: '+237 677 123 456',
      email: 'claire.dubois@libertis.cm',
      shift: 'Morning (6AM-2PM)',
      status: 'on-duty',
      rating: 4.8,
      languages: ['French', 'English'],
    },
    {
      id: 2,
      name: 'Jean-Paul Ngoma',
      role: 'Receptionist',
      department: 'reception',
      phone: '+237 655 987 654',
      email: 'jp.ngoma@libertis.cm',
      shift: 'Evening (2PM-10PM)',
      status: 'on-duty',
      rating: 4.6,
      languages: ['French', 'English', 'Bamileke'],
    },
    {
      id: 3,
      name: 'Marie Fotso',
      role: 'Head Housekeeper',
      department: 'housekeeping',
      phone: '+237 699 345 678',
      email: 'marie.fotso@libertis.cm',
      shift: 'Morning (7AM-3PM)',
      status: 'on-duty',
      rating: 4.9,
      languages: ['French', 'English'],
    },
    {
      id: 4,
      name: 'Emmanuel Biya',
      role: 'Chef de Cuisine',
      department: 'fnb',
      phone: '+237 678 456 789',
      email: 'emmanuel.biya@libertis.cm',
      shift: 'Split (11AM-3PM, 6PM-10PM)',
      status: 'break',
      rating: 4.7,
      languages: ['French', 'English'],
    },
    {
      id: 5,
      name: 'Aminata Koné',
      role: 'Events Coordinator',
      department: 'events',
      phone: '+237 655 234 567',
      email: 'aminata.kone@libertis.cm',
      shift: 'Flexible',
      status: 'on-duty',
      rating: 4.8,
      languages: ['French', 'English', 'Arabic'],
    },
    {
      id: 6,
      name: 'David Mballa',
      role: 'Maintenance Supervisor',
      department: 'maintenance',
      phone: '+237 677 890 123',
      email: 'david.mballa@libertis.cm',
      shift: 'Morning (6AM-2PM)',
      status: 'off-duty',
      rating: 4.5,
      languages: ['French', 'English'],
    },
  ];

  const getStatusBadge = (status: string) => {
    const statusStyles = {
      'on-duty': 'bg-green-100 text-green-800',
      'off-duty': 'bg-gray-100 text-gray-800',
      'break': 'bg-yellow-100 text-yellow-800',
    };
    
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusStyles[status as keyof typeof statusStyles]}`}>
        {status.replace('-', ' ')}
      </span>
    );
  };

  const filteredStaff = selectedDepartment === 'all' 
    ? staff 
    : staff.filter(member => member.department === selectedDepartment);

  return (
    <div className="space-y-6">
      {/* Department Filter */}
      <div className="flex flex-wrap gap-2">
        {departments.map((dept) => (
          <button
            key={dept.id}
            onClick={() => setSelectedDepartment(dept.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              selectedDepartment === dept.id
                ? 'bg-green-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {dept.label}
          </button>
        ))}
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStaff.map((member) => (
          <div key={member.id} className="bg-white rounded-lg border p-6 hover:shadow-md transition-shadow">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <User className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{member.name}</h3>
                  <p className="text-sm text-gray-600">{member.role}</p>
                </div>
              </div>
              {getStatusBadge(member.status)}
            </div>

            {/* Contact Info */}
            <div className="space-y-2 mb-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Phone className="h-4 w-4" />
                <span>{member.phone}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Mail className="h-4 w-4" />
                <span className="truncate">{member.email}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Clock className="h-4 w-4" />
                <span>{member.shift}</span>
              </div>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-2 mb-4">
              <Star className="h-4 w-4 text-yellow-500 fill-current" />
              <span className="text-sm font-medium text-gray-900">{member.rating}</span>
              <span className="text-sm text-gray-500">rating</span>
            </div>

            {/* Languages */}
            <div className="mb-4">
              <p className="text-xs font-medium text-gray-700 mb-2">Languages:</p>
              <div className="flex flex-wrap gap-1">
                {member.languages.map((lang, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full"
                  >
                    {lang}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-2">
              <button className="flex-1 bg-green-600 text-white py-2 px-3 rounded-md text-sm font-medium hover:bg-green-700 transition-colors">
                Contact
              </button>
              <button className="flex-1 bg-gray-200 text-gray-700 py-2 px-3 rounded-md text-sm font-medium hover:bg-gray-300 transition-colors">
                Schedule
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <User className="h-6 w-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Add Staff</span>
          </button>
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <Clock className="h-6 w-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Schedules</span>
          </button>
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <Star className="h-6 w-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Performance</span>
          </button>
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <MapPin className="h-6 w-6 text-gray-600 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-900">Assignments</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default StaffManagement;