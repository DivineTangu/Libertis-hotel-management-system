import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../../contexts/LanguageContext';
import LiveHotelMap from './dashboard/LiveHotelMap';
import RevenueWaterfall from './dashboard/RevenueWaterfall';
import KPICards from './dashboard/KPICards';
import AlertsPanel from './dashboard/AlertsPanel';

const ExecutiveDashboard: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <h1 className="text-4xl font-bold text-white mb-4">
          Executive Dashboard
        </h1>
        <p className="text-gray-300 text-lg">
          Real-time overview of LibertIs Hotel operations
        </p>
      </motion.div>

      {/* KPI Cards */}
      <KPICards />

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Live Hotel Map */}
        <div className="xl:col-span-2">
          <LiveHotelMap />
        </div>

        {/* Alerts Panel */}
        <div className="xl:col-span-1">
          <AlertsPanel />
        </div>
      </div>

      {/* Revenue Waterfall */}
      <RevenueWaterfall />
    </div>
  );
};

export default ExecutiveDashboard;