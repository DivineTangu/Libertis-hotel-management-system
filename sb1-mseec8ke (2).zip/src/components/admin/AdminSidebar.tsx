import React from 'react';
import { motion } from 'framer-motion';
import { NavLink } from 'react-router-dom';
import { 
  BarChart3, 
  Calendar, 
  Users, 
  Settings, 
  Bed, 
  Utensils, 
  Waves,
  Building
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface AdminSidebarProps {
  isOpen: boolean;
}

const AdminSidebar: React.FC<AdminSidebarProps> = ({ isOpen }) => {
  const { user } = useAuth();

  const menuItems = [
    {
      id: 'dashboard',
      label: 'Executive Dashboard',
      icon: BarChart3,
      path: '/admin/dashboard',
      roles: ['admin', 'receptionist', 'fnb_manager', 'events_coordinator']
    },
    {
      id: 'facilities',
      label: 'Facility Management',
      icon: Building,
      path: '/admin/facilities',
      roles: ['admin', 'receptionist', 'fnb_manager', 'events_coordinator']
    },
    {
      id: 'staff',
      label: 'Staff Management',
      icon: Users,
      path: '/admin/staff',
      roles: ['admin']
    },
    {
      id: 'analytics',
      label: 'Analytics & Reports',
      icon: BarChart3,
      path: '/admin/analytics',
      roles: ['admin', 'fnb_manager']
    }
  ];

  const facilityItems = [
    {
      id: 'rooms',
      label: 'Rooms',
      icon: Bed,
      roles: ['admin', 'receptionist']
    },
    {
      id: 'events',
      label: 'Events',
      icon: Calendar,
      roles: ['admin', 'events_coordinator']
    },
    {
      id: 'restaurant',
      label: 'Restaurant',
      icon: Utensils,
      roles: ['admin', 'fnb_manager']
    },
    {
      id: 'amenities',
      label: 'Amenities',
      icon: Waves,
      roles: ['admin', 'receptionist']
    }
  ];

  const filteredMenuItems = menuItems.filter(item => 
    item.roles.includes(user?.role || '')
  );

  const filteredFacilityItems = facilityItems.filter(item => 
    item.roles.includes(user?.role || '')
  );

  return (
    <motion.aside
      initial={{ x: -300 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed left-0 top-16 h-[calc(100vh-4rem)] backdrop-blur-xl bg-black/20 border-r border-white/10 transition-all duration-300 z-40 ${
        isOpen ? 'w-64' : 'w-16'
      }`}
    >
      <div className="p-4 space-y-6">
        {/* Main Navigation */}
        <div>
          {isOpen && (
            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
              Main Navigation
            </h3>
          )}
          <nav className="space-y-2">
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.id}
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/50'
                        : 'text-gray-300 hover:bg-white/10 hover:text-white'
                    }`
                  }
                >
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  {isOpen && <span className="font-medium">{item.label}</span>}
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Facility Quick Access */}
        {filteredFacilityItems.length > 0 && (
          <div>
            {isOpen && (
              <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
                Quick Access
              </h3>
            )}
            <nav className="space-y-2">
              {filteredFacilityItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
                  >
                    <Icon className="h-5 w-5 flex-shrink-0" />
                    {isOpen && <span className="font-medium">{item.label}</span>}
                  </button>
                );
              })}
            </nav>
          </div>
        )}

        {/* Settings */}
        <div className="pt-4 border-t border-white/10">
          <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-300 hover:bg-white/10 hover:text-white transition-colors">
            <Settings className="h-5 w-5 flex-shrink-0" />
            {isOpen && <span className="font-medium">Settings</span>}
          </button>
        </div>
      </div>
    </motion.aside>
  );
};

export default AdminSidebar;