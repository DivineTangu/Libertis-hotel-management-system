import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { TrendingUp, TrendingDown, DollarSign, Users, Calendar, Percent } from 'lucide-react';

const Analytics: React.FC = () => {
  const { t } = useLanguage();
  const [timeRange, setTimeRange] = useState('7d');

  const timeRanges = [
    { id: '7d', label: '7 Days' },
    { id: '30d', label: '30 Days' },
    { id: '3m', label: '3 Months' },
    { id: '1y', label: '1 Year' },
  ];

  const kpiData = [
    {
      title: 'Total Revenue',
      value: '4,105,000',
      unit: t('fcfa'),
      change: '+12.5%',
      trend: 'up',
      icon: DollarSign,
    },
    {
      title: 'Occupancy Rate',
      value: '72',
      unit: '%',
      change: '+5.2%',
      trend: 'up',
      icon: Percent,
    },
    {
      title: 'Total Guests',
      value: '156',
      unit: 'guests',
      change: '-2.1%',
      trend: 'down',
      icon: Users,
    },
    {
      title: 'Events Hosted',
      value: '8',
      unit: 'events',
      change: '+25.0%',
      trend: 'up',
      icon: Calendar,
    },
  ];

  const revenueByFacility = [
    { facility: 'Rooms', revenue: 2850000, percentage: 69.4 },
    { facility: 'Events', revenue: 750000, percentage: 18.3 },
    { facility: 'Restaurant', revenue: 420000, percentage: 10.2 },
    { facility: 'Amenities', revenue: 85000, percentage: 2.1 },
  ];

  const monthlyTrends = [
    { month: 'Jan', rooms: 2100000, events: 600000, fnb: 380000 },
    { month: 'Feb', rooms: 2300000, events: 550000, fnb: 400000 },
    { month: 'Mar', rooms: 2450000, events: 700000, fnb: 420000 },
    { month: 'Apr', rooms: 2200000, events: 650000, fnb: 390000 },
    { month: 'May', rooms: 2600000, events: 800000, fnb: 450000 },
    { month: 'Jun', rooms: 2850000, events: 750000, fnb: 420000 },
  ];

  const guestOrigins = [
    { country: 'Cameroon', guests: 89, percentage: 57.1 },
    { country: 'France', guests: 28, percentage: 17.9 },
    { country: 'Nigeria', guests: 18, percentage: 11.5 },
    { country: 'Chad', guests: 12, percentage: 7.7 },
    { country: 'Others', guests: 9, percentage: 5.8 },
  ];

  return (
    <div className="space-y-8">
      {/* Time Range Selector */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">Analytics & Reports</h3>
        <div className="flex space-x-2">
          {timeRanges.map((range) => (
            <button
              key={range.id}
              onClick={() => setTimeRange(range.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                timeRange === range.id
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => {
          const Icon = kpi.icon;
          const TrendIcon = kpi.trend === 'up' ? TrendingUp : TrendingDown;
          const trendColor = kpi.trend === 'up' ? 'text-green-600' : 'text-red-600';
          
          return (
            <div key={index} className="bg-white rounded-lg border p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="bg-green-100 p-2 rounded-lg">
                  <Icon className="h-6 w-6 text-green-600" />
                </div>
                <div className={`flex items-center space-x-1 ${trendColor}`}>
                  <TrendIcon className="h-4 w-4" />
                  <span className="text-sm font-medium">{kpi.change}</span>
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">
                  {kpi.value} <span className="text-sm font-normal text-gray-600">{kpi.unit}</span>
                </h3>
                <p className="text-sm text-gray-600">{kpi.title}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Revenue Breakdown */}
        <div className="bg-white rounded-lg border p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Revenue by Facility</h4>
          <div className="space-y-4">
            {revenueByFacility.map((item, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">{item.facility}</span>
                  <span className="text-sm text-gray-600">
                    {item.revenue.toLocaleString()} {t('fcfa')} ({item.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Guest Origins */}
        <div className="bg-white rounded-lg border p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Guest Origins</h4>
          <div className="space-y-3">
            {guestOrigins.map((origin, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-6 bg-gray-300 rounded flex items-center justify-center">
                    <span className="text-xs font-bold text-gray-600">
                      {origin.country.slice(0, 2).toUpperCase()}
                    </span>
                  </div>
                  <span className="font-medium text-gray-900">{origin.country}</span>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">{origin.guests}</div>
                  <div className="text-sm text-gray-600">{origin.percentage}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Monthly Trends */}
        <div className="lg:col-span-2 bg-white rounded-lg border p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Monthly Revenue Trends</h4>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Month</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">Rooms</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">Events</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">F&B</th>
                  <th className="text-right py-3 px-4 font-medium text-gray-700">Total</th>
                </tr>
              </thead>
              <tbody>
                {monthlyTrends.map((month, index) => {
                  const total = month.rooms + month.events + month.fnb;
                  return (
                    <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium text-gray-900">{month.month}</td>
                      <td className="py-3 px-4 text-right text-gray-700">
                        {month.rooms.toLocaleString()} {t('fcfa')}
                      </td>
                      <td className="py-3 px-4 text-right text-gray-700">
                        {month.events.toLocaleString()} {t('fcfa')}
                      </td>
                      <td className="py-3 px-4 text-right text-gray-700">
                        {month.fnb.toLocaleString()} {t('fcfa')}
                      </td>
                      <td className="py-3 px-4 text-right font-semibold text-gray-900">
                        {total.toLocaleString()} {t('fcfa')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Export Options */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Export Reports</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <span className="text-sm font-medium text-gray-900">Revenue Report</span>
          </button>
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <span className="text-sm font-medium text-gray-900">Occupancy Report</span>
          </button>
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <span className="text-sm font-medium text-gray-900">Guest Analysis</span>
          </button>
          <button className="bg-white border border-gray-300 p-4 rounded-lg text-center hover:bg-gray-50 transition-colors">
            <span className="text-sm font-medium text-gray-900">Full Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Analytics;