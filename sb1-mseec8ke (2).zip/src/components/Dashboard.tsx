import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import OccupancyCard from './dashboard/OccupancyCard';
import RevenueCard from './dashboard/RevenueCard';
import AlertsCard from './dashboard/AlertsCard';

const Dashboard: React.FC = () => {
  const { t } = useLanguage();

  const occupancyData = [
    { facility: t('rooms'), occupied: 28, total: 45, percentage: 62 },
    { facility: t('eventHall'), occupied: 1, total: 2, percentage: 50 },
    { facility: t('restaurant'), occupied: 18, total: 30, percentage: 60 },
    { facility: t('pool'), occupied: 15, total: 50, percentage: 30 },
  ];

  const revenueData = [
    { facility: t('rooms'), amount: 2850000, color: 'green' },
    { facility: t('eventHall'), amount: 750000, color: 'yellow' },
    { facility: t('restaurant'), amount: 420000, color: 'red' },
    { facility: t('pool'), amount: 85000, color: 'blue' },
  ];

  const alerts = [
    { type: t('checkins'), count: 12, time: '14:00' },
    { type: t('checkouts'), count: 8, time: '11:00' },
    { type: t('eventBookings'), count: 3, time: 'Today' },
  ];

  const totalRevenue = revenueData.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {t('dashboard')} - LibertIs Hotel
        </h1>
        <p className="text-gray-600">
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </p>
      </div>

      {/* Total Revenue Banner */}
      <div className="bg-gradient-to-r from-green-600 to-emerald-700 rounded-xl p-6 mb-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-medium opacity-90">{t('totalRevenue')}</h2>
            <p className="text-3xl font-bold">
              {totalRevenue.toLocaleString()} {t('fcfa')}
            </p>
          </div>
          <div className="text-right opacity-90">
            <p className="text-sm">Today</p>
            <p className="text-sm">+12.5% vs yesterday</p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Occupancy */}
        <div className="lg:col-span-1">
          <OccupancyCard data={occupancyData} />
        </div>

        {/* Revenue */}
        <div className="lg:col-span-1">
          <RevenueCard data={revenueData} />
        </div>

        {/* Alerts */}
        <div className="lg:col-span-1">
          <AlertsCard data={alerts} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;