import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowLeft, ArrowRight, CreditCard, Smartphone, Banknote } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface BookingFlowProps {
  facility: string;
  onClose: () => void;
}

const BookingFlow: React.FC<BookingFlowProps> = ({ facility, onClose }) => {
  const { t } = useLanguage();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    facility: facility,
    name: '',
    email: '',
    phone: '',
    checkinDate: '',
    checkoutDate: '',
    guests: '2',
    roomType: 'standard',
    eventType: 'wedding',
    tablePreference: 'any',
    amenityType: 'pool',
    paymentMethod: 'mtn',
    specialRequests: '',
  });

  const facilityConfig = {
    rooms: {
      title: 'Room Booking',
      steps: ['Details', 'Room Selection', 'Payment'],
      pricing: { standard: 45000, deluxe: 75000, suite: 120000 }
    },
    events: {
      title: 'Event Booking',
      steps: ['Details', 'Event Setup', 'Payment'],
      pricing: { wedding: 500000, conference: 300000, party: 250000 }
    },
    restaurant: {
      title: 'Restaurant Reservation',
      steps: ['Details', 'Table Selection', 'Confirmation'],
      pricing: { any: 0, window: 0, terrace: 0, private: 15000 }
    },
    amenities: {
      title: 'Amenities Booking',
      steps: ['Details', 'Amenity Selection', 'Payment'],
      pricing: { pool: 15000, gym: 3000, spa: 25000 }
    }
  };

  const config = facilityConfig[facility as keyof typeof facilityConfig];

  const paymentMethods = [
    { id: 'mtn', label: 'Mobile Money (MTN)', icon: Smartphone, color: 'from-yellow-500 to-yellow-600' },
    { id: 'orange', label: 'Mobile Money (Orange)', icon: Smartphone, color: 'from-orange-500 to-orange-600' },
    { id: 'card', label: 'Credit Card', icon: CreditCard, color: 'from-blue-500 to-blue-600' },
    { id: 'cash', label: 'Cash Payment', icon: Banknote, color: 'from-green-500 to-green-600' },
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateTotal = () => {
    const basePrice = config.pricing[formData.roomType as keyof typeof config.pricing] || 
                     config.pricing[formData.eventType as keyof typeof config.pricing] ||
                     config.pricing[formData.tablePreference as keyof typeof config.pricing] ||
                     config.pricing[formData.amenityType as keyof typeof config.pricing] || 0;
    
    const vat = basePrice * 0.1925;
    const tourismTax = facility === 'rooms' ? 2500 : 0;
    return basePrice + vat + tourismTax;
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">Guest Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
                  placeholder="Enter your full name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
                  placeholder="your@email.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Phone</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
                  placeholder="+237 xxx xxx xxx"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Number of Guests</label>
                <select
                  value={formData.guests}
                  onChange={(e) => handleInputChange('guests', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
                >
                  {[1,2,3,4,5,6,7,8,9,10].map(num => (
                    <option key={num} value={num} className="bg-gray-800">{num} guest{num > 1 ? 's' : ''}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Check-in Date</label>
                <input
                  type="date"
                  value={formData.checkinDate}
                  onChange={(e) => handleInputChange('checkinDate', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Check-out Date</label>
                <input
                  type="date"
                  value={formData.checkoutDate}
                  onChange={(e) => handleInputChange('checkoutDate', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">
              {facility === 'rooms' && 'Select Room Type'}
              {facility === 'events' && 'Event Configuration'}
              {facility === 'restaurant' && 'Table Preference'}
              {facility === 'amenities' && 'Select Amenity'}
            </h3>
            
            {facility === 'rooms' && (
              <div className="space-y-4">
                {Object.entries(config.pricing).map(([type, price]) => (
                  <motion.label
                    key={type}
                    whileHover={{ scale: 1.02 }}
                    className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                      formData.roomType === type
                        ? 'bg-emerald-600/30 border-2 border-emerald-500'
                        : 'bg-white/10 border border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <input
                        type="radio"
                        name="roomType"
                        value={type}
                        checked={formData.roomType === type}
                        onChange={(e) => handleInputChange('roomType', e.target.value)}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <div>
                        <span className="font-medium text-white capitalize">{type} Room</span>
                        <p className="text-sm text-gray-400">
                          {type === 'standard' && 'Comfortable accommodation with essential amenities'}
                          {type === 'deluxe' && 'Spacious room with premium features and city view'}
                          {type === 'suite' && 'Luxurious suite with separate living area and panoramic views'}
                        </p>
                      </div>
                    </div>
                    <span className="text-emerald-400 font-bold">
                      {price.toLocaleString()} FCFA/night
                    </span>
                  </motion.label>
                ))}
              </div>
            )}

            {facility === 'events' && (
              <div className="space-y-4">
                {Object.entries(config.pricing).map(([type, price]) => (
                  <motion.label
                    key={type}
                    whileHover={{ scale: 1.02 }}
                    className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                      formData.eventType === type
                        ? 'bg-red-600/30 border-2 border-red-500'
                        : 'bg-white/10 border border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <input
                        type="radio"
                        name="eventType"
                        value={type}
                        checked={formData.eventType === type}
                        onChange={(e) => handleInputChange('eventType', e.target.value)}
                        className="text-red-600 focus:ring-red-500"
                      />
                      <span className="font-medium text-white capitalize">{type}</span>
                    </div>
                    <span className="text-red-400 font-bold">
                      {price.toLocaleString()} FCFA
                    </span>
                  </motion.label>
                ))}
              </div>
            )}

            {facility === 'amenities' && (
              <div className="space-y-4">
                {Object.entries(config.pricing).map(([type, price]) => (
                  <motion.label
                    key={type}
                    whileHover={{ scale: 1.02 }}
                    className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                      formData.amenityType === type
                        ? 'bg-blue-600/30 border-2 border-blue-500'
                        : 'bg-white/10 border border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <input
                        type="radio"
                        name="amenityType"
                        value={type}
                        checked={formData.amenityType === type}
                        onChange={(e) => handleInputChange('amenityType', e.target.value)}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <span className="font-medium text-white capitalize">{type} Access</span>
                    </div>
                    <span className="text-blue-400 font-bold">
                      {price.toLocaleString()} FCFA/day
                    </span>
                  </motion.label>
                ))}
              </div>
            )}
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-6">Payment Method</h3>
            
            {/* Payment Methods */}
            <div className="space-y-4">
              {paymentMethods.map((method) => {
                const Icon = method.icon;
                return (
                  <motion.label
                    key={method.id}
                    whileHover={{ scale: 1.02 }}
                    className={`flex items-center p-4 rounded-xl cursor-pointer transition-all ${
                      formData.paymentMethod === method.id
                        ? 'bg-gradient-to-r ' + method.color + ' border-2 border-white/50'
                        : 'bg-white/10 border border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value={method.id}
                      checked={formData.paymentMethod === method.id}
                      onChange={(e) => handleInputChange('paymentMethod', e.target.value)}
                      className="text-white focus:ring-white"
                    />
                    <Icon className="h-6 w-6 ml-3 mr-3 text-white" />
                    <span className="font-medium text-white">{method.label}</span>
                  </motion.label>
                );
              })}
            </div>

            {/* Booking Summary */}
            <div className="bg-white/10 rounded-xl p-6 border border-white/20">
              <h4 className="text-lg font-semibold text-white mb-4">Booking Summary</h4>
              <div className="space-y-3">
                <div className="flex justify-between text-gray-300">
                  <span>Base Price</span>
                  <span>{(calculateTotal() - (calculateTotal() * 0.1925) - (facility === 'rooms' ? 2500 : 0)).toLocaleString()} FCFA</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>VAT (19.25%)</span>
                  <span>{Math.round(calculateTotal() * 0.1925).toLocaleString()} FCFA</span>
                </div>
                {facility === 'rooms' && (
                  <div className="flex justify-between text-gray-300">
                    <span>Tourism Tax</span>
                    <span>2,500 FCFA</span>
                  </div>
                )}
                <div className="border-t border-white/20 pt-3">
                  <div className="flex justify-between text-white font-bold text-lg">
                    <span>Total</span>
                    <span>{calculateTotal().toLocaleString()} FCFA</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900/95 to-emerald-900/95 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="sticky top-0 bg-gradient-to-r from-emerald-600/20 to-red-600/20 backdrop-blur-xl border-b border-white/20 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">{config.title}</h2>
                <p className="text-gray-300">Step {step} of {config.steps.length}: {config.steps[step - 1]}</p>
              </div>
              <button
                onClick={onClose}
                className="p-2 text-gray-400 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Progress Bar */}
            <div className="mt-4 w-full bg-white/20 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-emerald-500 to-red-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(step / config.steps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {renderStepContent()}
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 bg-gradient-to-r from-slate-900/95 to-emerald-900/95 backdrop-blur-xl border-t border-white/20 p-6">
            <div className="flex justify-between">
              <button
                onClick={() => step > 1 ? setStep(step - 1) : onClose()}
                className="flex items-center space-x-2 px-6 py-3 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>{step > 1 ? 'Previous' : 'Cancel'}</span>
              </button>

              <button
                onClick={() => step < config.steps.length ? setStep(step + 1) : onClose()}
                className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-red-600 text-white rounded-xl hover:from-emerald-700 hover:to-red-700 transition-all"
              >
                <span>{step < config.steps.length ? 'Next' : 'Complete Booking'}</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default BookingFlow;