import React from 'react';
import { motion } from 'framer-motion';
import { Bed, Users, Utensils, Waves, Dumbbell, Sparkles, Calendar, Wine } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface AmenitiesGalleryProps {
  onBookingOpen: (facility: string) => void;
}

const AmenitiesGallery: React.FC<AmenitiesGalleryProps> = ({ onBookingOpen }) => {
  const { t } = useLanguage();

  const amenities = [
    {
      id: 'rooms',
      title: 'Luxury Accommodations',
      subtitle: 'Standard • Deluxe • Suite',
      description: 'Elegantly appointed rooms with panoramic city views, premium amenities, and authentic Cameroonian touches.',
      image: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg',
      icon: Bed,
      pricing: 'From 45,000 FCFA/night',
      features: ['City Views', 'Premium Bedding', 'Mini Bar', 'Free WiFi'],
      gradient: 'from-emerald-600 to-emerald-800'
    },
    {
      id: 'events',
      title: 'Event Halls',
      subtitle: 'Weddings • Conferences • Celebrations',
      description: 'State-of-the-art venues accommodating 50-500 guests with professional event planning services.',
      image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg',
      icon: Users,
      pricing: 'From 250,000 FCFA/event',
      features: ['Professional AV', 'Catering Service', 'Event Planning', 'Flexible Layouts'],
      gradient: 'from-red-600 to-red-800'
    },
    {
      id: 'restaurant',
      title: 'Restaurant & Bar',
      subtitle: 'Ndolé • Poulet DG • International Cuisine',
      description: 'Savor authentic Cameroonian delicacies alongside international favorites in our elegant dining spaces.',
      image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg',
      icon: Utensils,
      pricing: 'Ndolé: 4,500 FCFA',
      features: ['Local Specialties', 'Wine Selection', 'Terrace Dining', 'Private Rooms'],
      gradient: 'from-yellow-600 to-orange-600'
    },
    {
      id: 'pool',
      title: 'Infinity Pool',
      subtitle: 'Resort-Style Relaxation',
      description: 'Stunning infinity pool with panoramic views, poolside service, and dedicated relaxation areas.',
      image: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg',
      icon: Waves,
      pricing: 'Day Pass: 15,000 FCFA',
      features: ['Infinity Design', 'Poolside Bar', 'Cabanas', 'City Views'],
      gradient: 'from-blue-600 to-cyan-600'
    },
    {
      id: 'gym',
      title: 'Fitness Center',
      subtitle: 'Modern Equipment • Personal Training',
      description: 'Fully equipped fitness center with modern equipment, personal training, and wellness programs.',
      image: 'https://images.pexels.com/photos/1552252/pexels-photo-1552252.jpeg',
      icon: Dumbbell,
      pricing: 'Access: 3,000 FCFA/day',
      features: ['Modern Equipment', 'Personal Trainers', 'Group Classes', 'Wellness Programs'],
      gradient: 'from-purple-600 to-indigo-600'
    },
    {
      id: 'spa',
      title: 'Spa & Wellness',
      subtitle: 'Rejuvenation • Traditional Treatments',
      description: 'Luxurious spa treatments combining modern techniques with traditional Cameroonian wellness practices.',
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg',
      icon: Sparkles,
      pricing: 'Treatments from 25,000 FCFA',
      features: ['Traditional Treatments', 'Modern Techniques', 'Relaxation Suites', 'Wellness Packages'],
      gradient: 'from-pink-600 to-rose-600'
    }
  ];

  return (
    <section id="amenities" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            World-Class Amenities
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover our exceptional facilities designed to exceed your expectations
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {amenities.map((amenity, index) => {
            const Icon = amenity.icon;
            return (
              <motion.div
                key={amenity.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="group relative overflow-hidden rounded-2xl backdrop-blur-lg bg-white/10 border border-white/20 shadow-2xl"
              >
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={amenity.image}
                    alt={amenity.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${amenity.gradient} opacity-60`} />
                  
                  {/* Icon Overlay */}
                  <div className="absolute top-4 right-4">
                    <div className="bg-white/20 backdrop-blur-sm rounded-full p-3">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                  </div>

                  {/* Pricing Badge */}
                  <div className="absolute bottom-4 left-4">
                    <div className="bg-black/50 backdrop-blur-sm rounded-full px-4 py-2">
                      <span className="text-white font-semibold text-sm">{amenity.pricing}</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{amenity.title}</h3>
                  <p className="text-emerald-400 text-sm font-medium mb-3">{amenity.subtitle}</p>
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed">{amenity.description}</p>
                  
                  {/* Features */}
                  <div className="grid grid-cols-2 gap-2 mb-6">
                    {amenity.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center space-x-2">
                        <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                        <span className="text-xs text-gray-400">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* Book Button */}
                  <motion.button
                    onClick={() => onBookingOpen(amenity.id)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-full bg-gradient-to-r ${amenity.gradient} text-white py-3 px-4 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-xl`}
                  >
                    Book Now
                  </motion.button>
                </div>

                {/* Hover Effect Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default AmenitiesGallery;