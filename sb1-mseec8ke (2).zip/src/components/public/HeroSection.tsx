import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Users, Utensils, Waves, ChevronDown } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface HeroSectionProps {
  onBookingOpen: (facility: string) => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onBookingOpen }) => {
  const { t } = useLanguage();
  const [selectedFacility, setSelectedFacility] = useState('rooms');

  const facilities = [
    { id: 'rooms', label: 'Rooms', icon: Calendar },
    { id: 'events', label: 'Events', icon: Users },
    { id: 'restaurant', label: 'Restaurant', icon: Utensils },
    { id: 'amenities', label: 'Amenities', icon: Waves },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-emerald-900/40 to-red-900/30 z-10" />
        <div className="w-full h-full bg-gradient-to-br from-slate-900 via-emerald-800 to-slate-700" />
        {/* Placeholder for video - in production, replace with actual video */}
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg')] bg-cover bg-center opacity-30" />
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 z-10">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white/20 rounded-full"
            initial={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white via-emerald-200 to-yellow-200 bg-clip-text text-transparent">
              Welcome to
            </span>
            <br />
            <span className="bg-gradient-to-r from-emerald-400 to-red-400 bg-clip-text text-transparent">
              LibertIs Hotel
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Experience luxury redefined in the heart of Cameroon. Where modern elegance meets authentic hospitality.
          </p>
        </motion.div>

        {/* Floating Booking Widget */}
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="backdrop-blur-xl bg-white/10 rounded-3xl p-8 border border-white/20 shadow-2xl max-w-4xl mx-auto"
        >
          <h3 className="text-2xl font-semibold text-white mb-6">Book Your Experience</h3>
          
          {/* Facility Toggle */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {facilities.map((facility) => {
              const Icon = facility.icon;
              return (
                <motion.button
                  key={facility.id}
                  onClick={() => setSelectedFacility(facility.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    selectedFacility === facility.id
                      ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 text-white shadow-lg'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20'
                  }`}
                >
                  <Icon className="h-6 w-6 mx-auto mb-2" />
                  <span className="text-sm font-medium">{facility.label}</span>
                </motion.button>
              );
            })}
          </div>

          {/* Quick Booking Form */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Check-in</label>
              <input
                type="date"
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Check-out</label>
              <input
                type="date"
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Guests</label>
              <select className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 backdrop-blur-sm">
                <option value="1">1 Guest</option>
                <option value="2">2 Guests</option>
                <option value="3">3 Guests</option>
                <option value="4">4+ Guests</option>
              </select>
            </div>
          </div>

          <motion.button
            onClick={() => onBookingOpen(selectedFacility)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-gradient-to-r from-red-600 to-yellow-600 text-white py-4 px-8 rounded-xl font-semibold text-lg hover:from-red-700 hover:to-yellow-700 transition-all duration-300 shadow-lg"
          >
            Book Now
          </motion.button>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 2 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-white/60"
          >
            <ChevronDown className="h-8 w-8" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;