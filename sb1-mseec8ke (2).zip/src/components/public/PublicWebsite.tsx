import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../../contexts/LanguageContext';
import HeroSection from './HeroSection';
import AmenitiesGallery from './AmenitiesGallery';
import BookingFlow from './BookingFlow';
import Footer from './Footer';
import PublicHeader from './PublicHeader';

const PublicWebsite: React.FC = () => {
  const { t } = useLanguage();
  const [showBooking, setShowBooking] = useState(false);
  const [selectedFacility, setSelectedFacility] = useState<string>('rooms');

  const handleBookingOpen = (facility: string) => {
    setSelectedFacility(facility);
    setShowBooking(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-800">
      <PublicHeader />
      
      {/* Hero Section */}
      <HeroSection onBookingOpen={handleBookingOpen} />
      
      {/* Amenities Gallery */}
      <AmenitiesGallery onBookingOpen={handleBookingOpen} />
      
      {/* About Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Experience Luxury in the Heart of Cameroon
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              LibertIs Hotel combines modern sophistication with authentic Cameroonian hospitality. 
              From our infinity pool overlooking the city to our world-class event facilities, 
              every detail is crafted for an unforgettable experience.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Luxury Accommodations',
                description: 'Elegantly appointed rooms and suites with panoramic city views',
                icon: '🏨'
              },
              {
                title: 'World-Class Events',
                description: 'State-of-the-art facilities for weddings, conferences, and celebrations',
                icon: '🎉'
              },
              {
                title: 'Authentic Cuisine',
                description: 'Savor traditional Cameroonian dishes alongside international favorites',
                icon: '🍽️'
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="backdrop-blur-lg bg-white/10 rounded-2xl p-8 border border-white/20"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-4">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-emerald-600/20 to-red-600/20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-8">
              Ready to Experience LibertIs?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="backdrop-blur-lg bg-white/10 rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-semibold text-white mb-4">Contact Information</h3>
                <div className="space-y-2 text-gray-300">
                  <p>📍 Douala, Cameroon</p>
                  <p>📞 +237 677 123 456</p>
                  <p>✉️ info@libertis-hotel.cm</p>
                </div>
              </div>
              <div className="backdrop-blur-lg bg-white/10 rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-semibold text-white mb-4">Operating Hours</h3>
                <div className="space-y-2 text-gray-300">
                  <p>Reception: 24/7</p>
                  <p>Restaurant: 6:00 AM - 11:00 PM</p>
                  <p>Pool & Gym: 5:00 AM - 10:00 PM</p>
                </div>
              </div>
            </div>
            <button
              onClick={() => handleBookingOpen('rooms')}
              className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:from-emerald-700 hover:to-emerald-800 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Book Your Stay Now
            </button>
          </motion.div>
        </div>
      </section>

      <Footer />

      {/* Booking Flow Modal */}
      {showBooking && (
        <BookingFlow
          facility={selectedFacility}
          onClose={() => setShowBooking(false)}
        />
      )}
    </div>
  );
};

export default PublicWebsite;